#pragma once
#include "main.h"

extern const threedmodel cube;